//Name: Kenneth Gollaher
//Course: CS 210: Project 2
//Date: 06/06/2021

#include <iostream>
#include <cstring>
#include <iomanip>
#include <cstdlib>

using namespace std;

// variables added for data input
float initialInvest;
float monthlyDeposit;
float annualInterest;
int years;
int months;
float totalAmount;
float interestAmount;
float yearTotalInterest;

int main() { //main function

	// displaying menu to user and printing to screen
	cout << "**********************************" << endl;
	cout << "********** Data Input ************" << endl;
	cout << "Initial Investment Amount: " << endl;
	cout << "Monthly Deposit: " << endl;
	cout << "Annual Interest: " << endl;
	cout << "Number of years: " << endl;
	system("PAUSE");
	system("CLS");

	// requesting user input for their initial investment amount
	cout << "**********************************" << endl;
	cout << "********** Data Input ************" << endl;
	cout << "Initial Investment Amount: $";
	cin >> initialInvest;
	if (initialInvest < 0) {
		cout << "Initial investment amount cannot be less than $0.00" << endl;
		cout << "Initial Investment Amount: $";
		cin >> initialInvest;
	};
	// requesting user input for their monthly deposit amount
	cout << "Monthly Deposit: $";
	cin >> monthlyDeposit;
	if (monthlyDeposit < 0) {
		cout << "Monthly deposit amount cannot be less than $0.00" << endl;
		cout << "Monthly Deposit: $";
		cin >> monthlyDeposit;
	};
	// requesting user input for desired annual interest amount
	cout << "Annual Interest: %";
	cin >> annualInterest;

	// requesting user input for number of years
	cout << "Number of years: ";
	cin >> years;
	months = years * 12;
	system("PAUSE");
	system("CLS");

	// define the initial investment to totalAmt
	totalAmount = initialInvest;

	// displaying the year data to the user with NO monthly deposits
	cout << "     Balance and Interest Without Additional Monthly Deposits     " << endl;
	cout << "==================================================================" << endl;
	cout << "   Year        Year End Balance     Year End Earned Interest      " << endl;
	cout << "------------------------------------------------------------------" << endl;

	// for loop added to execute year data without monthly deposits
	for (int i = 0; i < years; i++) {
		interestAmount = (totalAmount) * ((annualInterest / 100)); // calculation for year interest

		totalAmount = totalAmount + interestAmount; // calculation to add interest amount to total amount

		// manipulator function used for two decimal places for output
		cout << "     " << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << interestAmount << "\n";
	}

	totalAmount = initialInvest; // updated total amount
	cout << endl;

	// displaying the year data to the user with monthly deposits
	cout << "       Balance and Interest With Additional Monthly Deposits      " << endl;
	cout << "==================================================================" << endl;
	cout << "   Year        Year End Balance     Year End Earned Interest      " << endl;
	cout << "------------------------------------------------------------------" << endl;

	// for loop added to execute year data with monthly deposits
	for (int i = 0; i < years; i++) {
		yearTotalInterest = 0; // define yearly interest to zero for the beginning of each year
		for (int j = 0; j < 12; j++) {
			interestAmount = (totalAmount + monthlyDeposit) * ((annualInterest / 100) / 12); // monthly interest calculation
			yearTotalInterest = yearTotalInterest + interestAmount; // yearly interest calculation
			totalAmount = totalAmount + monthlyDeposit + interestAmount; // total amount of interest plus total deposit
		}
		// manipulator function used for two decimal places for output
		cout << "     " << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t$" << yearTotalInterest << "\n";;
	}
	return 0;
}
